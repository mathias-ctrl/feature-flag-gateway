---
name: Bug report
about: Relate um comportamento incorreto
title: "bug: "
labels: bug
assignees: ""
---

## Descrição

## Como reproduzir

## Comportamento esperado

## Logs relevantes

## Ambiente
