---
name: Feature request
about: Sugira uma melhoria
title: "feat: "
labels: enhancement
assignees: ""
---

## Problema

## Solução proposta

## Alternativas consideradas

## Impacto esperado
