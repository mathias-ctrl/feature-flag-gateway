## O que mudou

## Por que

## Como testar

## Checklist

- [ ] Adicionei ou atualizei testes
- [ ] A cobertura permanece acima de 85%
- [ ] Ruff passou
- [ ] mypy passou
- [ ] Não incluí segredos
- [ ] Atualizei a documentação
